import 'package:flutter_test/flutter_test.dart';
import 'package:game_catalog_flutter/main.dart';
import 'package:flutter/material.dart';

void main() {
  testWidgets('beranda dan navigasi daftar game tampil', (tester) async {
    await tester.pumpWidget(const GameCatalogApp());
    expect(find.text('Selamat Datang'), findsOneWidget);
    expect(find.text('Game Populer'), findsOneWidget);
    await tester.tap(find.text('Daftar Game'));
    await tester.pumpAndSettle();
    expect(find.text('Daftar game'), findsOneWidget);
    expect(find.text('Overwatch 2'), findsWidgets);
  });
}
