# GameVerse - Katalog Game Flutter

Aplikasi katalog game dibuat sebagai contoh UTS Mobile Programming. Desain antarmuka mengacu pada gaya referensi yang menampilkan header gelap, latar krem, kategori bergambar, kartu game populer, tombol oranye "Baca Info", dan halaman detail berisi spesifikasi minimum.

## Fitur
- Beranda: kolom pencarian, kategori, game populer dan game terbaru.
- Daftar game: pencarian berdasarkan judul/genre dan filter kategori.
- Detail game: informasi deskripsi, genre, platform, rating, tanggal rilis, persyaratan minimum, dan game serupa.
- Favorit: simpan/hapus game melalui ikon hati.
- Navigasi memakai `NavigationBar` dan `Navigator.push`.
- Artwork orisinal disimpan lokal pada `assets/images/`; aplikasi tidak perlu mengunduh gambar dari internet.

## Struktur folder
```text
game_catalog_flutter/
├── assets/images/             # Ilustrasi game orisinal
├── lib/
│   ├── data/game_data.dart    # Data dummy katalog
│   ├── models/game.dart       # Model data Game
│   ├── pages/                 # Beranda, daftar, detail, favorit
│   ├── state/                 # State favorit dalam memori
│   ├── widgets/               # Kartu game yang dipakai ulang
│   └── main.dart              # Tema, routing, dan navigasi utama
├── docs/ui_mockups/           # Mockup perancangan UI
├── test/widget_test.dart      # Pengujian widget dasar
└── pubspec.yaml
```

## Cara menjalankan
1. Install Flutter SDK dan Android Studio atau VS Code dengan ekstensi Flutter.
2. Ekstrak ZIP, lalu buka folder `game_catalog_flutter`.
3. Pada terminal di folder proyek, jalankan:
   ```bash
   flutter pub get
   flutter test
   flutter run
   ```
4. Pilih emulator Android atau perangkat yang telah mengaktifkan USB debugging.

## Catatan data
Semua entri katalog merupakan data dummy untuk demonstrasi UI dan pembelajaran. Spesifikasi minimum yang ditampilkan adalah contoh data, bukan referensi resmi terbaru dari penerbit game. Data favorit hanya tersimpan selama aplikasi berjalan; penyimpanan persisten dan integrasi API belum diterapkan.

## Rencana pengembangan
- Mengganti data dummy dengan model JSON dari REST API.
- Menyimpan favorit melalui SQLite/SharedPreferences.
- Menambah halaman filter lanjutan dan detail platform.
- Melakukan pengujian pada berbagai ukuran layar perangkat.
