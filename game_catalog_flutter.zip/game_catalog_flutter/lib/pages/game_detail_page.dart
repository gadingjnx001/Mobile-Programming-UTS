
import 'package:flutter/material.dart';

import '../data/game_data.dart';
import '../main.dart';
import '../models/game.dart';
import '../state/favorites_store.dart';
import '../widgets/game_card.dart';

class GameDetailPage extends StatelessWidget {
  const GameDetailPage({
    super.key,
    required this.game,
  });

  final Game game;

  @override
  Widget build(BuildContext context) {
    final relatedGames = games
        .where(
          (item) =>
      item.id != game.id &&
          item.category == game.category,
    )
        .take(3)
        .toList();

    return Scaffold(
      backgroundColor: gameCream,
      body: CustomScrollView(
        slivers: [
          // Header gambar game
          SliverToBoxAdapter(
            child: SizedBox(
              height: 248,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  Image.asset(
                    game.imageAsset,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      return Container(
                        color: gameNavy,
                        alignment: Alignment.center,
                        child: const Icon(
                          Icons.broken_image,
                          color: Colors.white,
                          size: 50,
                        ),
                      );
                    },
                  ),

                  const DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Color(0x33000000),
                          Colors.transparent,
                          Color(0x44000000),
                        ],
                      ),
                    ),
                  ),

                  // Tombol kembali
                  Positioned(
                    top: MediaQuery.paddingOf(context).top + 7,
                    left: 14,
                    child: CircleAvatar(
                      backgroundColor: const Color(0xCC12383D),
                      child: IconButton(
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                        icon: const Icon(
                          Icons.arrow_back,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),

                  // Tombol favorit
                  Positioned(
                    top: MediaQuery.paddingOf(context).top + 7,
                    right: 14,
                    child: ValueListenableBuilder<Set<String>>(
                      valueListenable: favoriteGameIds,
                      builder: (context, favs, _) {
                        final isFavorite = favs.contains(game.id);

                        return CircleAvatar(
                          backgroundColor: const Color(0xCC12383D),
                          child: IconButton(
                            onPressed: () {
                              toggleFavorite(game.id);
                            },
                            icon: Icon(
                              isFavorite
                                  ? Icons.favorite
                                  : Icons.favorite_border,
                              color: isFavorite
                                  ? Colors.pinkAccent
                                  : Colors.white,
                            ),
                          ),
                        );
                      },
                    ),
                  ),

                  // Judul game
                  Positioned(
                    left: 18,
                    right: 18,
                    bottom: 16,
                    child: Text(
                      game.title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 25,
                        fontWeight: FontWeight.w900,
                        shadows: [
                          Shadow(
                            color: Colors.black54,
                            blurRadius: 8,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Genre, rating, dan platform
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(17, 13, 17, 7),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 6,
                    ),
                    decoration: BoxDecoration(
                      color: gameNavy,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      game.genre,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),

                  const SizedBox(width: 8),

                  const Icon(
                    Icons.star,
                    color: Color(0xFFFFA800),
                    size: 18,
                  ),

                  const SizedBox(width: 3),

                  Text(
                    game.rating.toStringAsFixed(1),
                    style: const TextStyle(
                      fontWeight: FontWeight.w800,
                    ),
                  ),

                  const Spacer(),

                  Flexible(
                    child: Text(
                      game.platform,
                      textAlign: TextAlign.end,
                      style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: gameTeal,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Persyaratan sistem minimum
          SliverToBoxAdapter(
            child: Container(
              margin: const EdgeInsets.fromLTRB(15, 8, 15, 12),
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(17),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Minimum System Requirements',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w900,
                    ),
                  ),

                  const SizedBox(height: 12),

                  _RequirementRow(
                    label: 'OS',
                    value: game.minOs,
                  ),
                  _RequirementRow(
                    label: 'Processor',
                    value: game.minProcessor,
                  ),
                  _RequirementRow(
                    label: 'Memory',
                    value: game.minMemory,
                  ),
                  _RequirementRow(
                    label: 'Graphics',
                    value: game.minGraphics,
                  ),
                  _RequirementRow(
                    label: 'Storage',
                    value: game.storage,
                  ),
                ],
              ),
            ),
          ),

          // Deskripsi game
          const SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.fromLTRB(17, 1, 17, 7),
              child: Text(
                'Tentang game',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ),

          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(17, 0, 17, 10),
              child: Text(
                '${game.description}\n\n'
                    'Tanggal rilis pada katalog: ${game.releaseDate}.',
                style: TextStyle(
                  fontSize: 12,
                  height: 1.5,
                  color: Colors.blueGrey.shade800,
                ),
              ),
            ),
          ),

          // Game serupa
          if (relatedGames.isNotEmpty) ...[
            const SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.fromLTRB(17, 5, 17, 10),
                child: Text(
                  'Game serupa',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ),

            SliverToBoxAdapter(
              child: SizedBox(
                height: 145,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  children: relatedGames.map((item) {
                    return GameArtworkCard(
                      game: item,
                      onTap: () {
                        Navigator.of(context).pushReplacement(
                          MaterialPageRoute<void>(
                            builder: (_) => GameDetailPage(
                              game: item,
                            ),
                          ),
                        );
                      },
                    );
                  }).toList(),
                ),
              ),
            ),
          ],

          const SliverToBoxAdapter(
            child: SizedBox(height: 25),
          ),
        ],
      ),
    );
  }
}

class _RequirementRow extends StatelessWidget {
  const _RequirementRow({
    required this.label,
    required this.value,
  });

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 83,
            child: Text(
              label,
              style: TextStyle(
                fontSize: 11,
                color: Colors.blueGrey.shade600,
              ),
            ),
          ),

          const Text(
            ':  ',
            style: TextStyle(fontSize: 11),
          ),

          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
