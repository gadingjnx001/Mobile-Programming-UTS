
import 'package:flutter/material.dart';

import '../data/game_data.dart';
import '../main.dart';
import '../models/game.dart';
import '../widgets/game_card.dart';

class ExplorePage extends StatefulWidget {
  const ExplorePage({
    super.key,
    required this.initialQuery,
    required this.initialCategory,
    required this.onOpenGame,
  });

  final String initialQuery;
  final String initialCategory;
  final ValueChanged<Game> onOpenGame;

  @override
  State<ExplorePage> createState() => _ExplorePageState();
}

class _ExplorePageState extends State<ExplorePage> {
  late final TextEditingController _controller;
  late String _query;
  late String _category;

  @override
  void initState() {
    super.initState();

    _controller = TextEditingController(
      text: widget.initialQuery,
    );

    _query = widget.initialQuery;
    _category = widget.initialCategory;
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final filteredGames = games.where((game) {
      final query = _query.toLowerCase().trim();

      final matchesQuery =
          game.title.toLowerCase().contains(query) ||
              game.genre.toLowerCase().contains(query) ||
              game.category.toLowerCase().contains(query);

      final matchesCategory =
          _category == 'Semua' || game.category == _category;

      return matchesQuery && matchesCategory;
    }).toList();

    return SafeArea(
      bottom: false,
      child: Column(
        children: [
          // Header dan kolom pencarian
          Container(
            width: double.infinity,
            color: gameNavy,
            padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Daftar game',
                  style: TextStyle(
                    fontSize: 21,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                  ),
                ),

                const SizedBox(height: 13),

                Container(
                  decoration: BoxDecoration(
                    color: gameTeal,
                    borderRadius: BorderRadius.circular(13),
                  ),
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: Row(
                    children: [
                      const Icon(
                        Icons.search,
                        color: gameOrange,
                      ),

                      const SizedBox(width: 7),

                      Expanded(
                        child: TextField(
                          controller: _controller,
                          onChanged: (value) {
                            setState(() {
                              _query = value;
                            });
                          },
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                          ),
                          decoration: const InputDecoration(
                            hintText: 'Cari judul atau genre game',
                            hintStyle: TextStyle(
                              color: Color(0xFFC3D1D1),
                              fontSize: 11,
                            ),
                            border: InputBorder.none,
                            isDense: true,
                            contentPadding: EdgeInsets.symmetric(
                              vertical: 13,
                            ),
                          ),
                        ),
                      ),

                      if (_controller.text.isNotEmpty)
                        IconButton(
                          onPressed: () {
                            _controller.clear();

                            setState(() {
                              _query = '';
                            });
                          },
                          icon: const Icon(
                            Icons.close,
                            color: Colors.white,
                            size: 18,
                          ),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Filter kategori
          SizedBox(
            height: 55,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(
                horizontal: 14,
                vertical: 9,
              ),
              children: gameCategories.map((category) {
                final isSelected = category == _category;

                return Padding(
                  padding: const EdgeInsets.only(right: 7),
                  child: ChoiceChip(
                    label: Text(category),
                    selected: isSelected,
                    onSelected: (_) {
                      setState(() {
                        _category = category;
                      });
                    },
                    selectedColor: gameOrange,
                    backgroundColor: Colors.white,
                    labelStyle: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      color: isSelected ? gameNavy : gameInk,
                    ),
                    side: BorderSide.none,
                  ),
                );
              }).toList(),
            ),
          ),

          // Daftar game hasil pencarian
          Expanded(
            child: filteredGames.isEmpty
                ? const Center(
              child: Text(
                'Game tidak ditemukan. Coba kata kunci lain.',
                textAlign: TextAlign.center,
              ),
            )
                : ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 5, 16, 18),
              itemCount: filteredGames.length,
              itemBuilder: (context, index) {
                final game = filteredGames[index];

                return GameListCard(
                  game: game,
                  onTap: () => widget.onOpenGame(game),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
