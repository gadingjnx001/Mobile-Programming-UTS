import 'package:flutter/material.dart';

import '../data/game_data.dart';
import '../main.dart';
import '../models/game.dart';
import '../state/favorites_store.dart';
import '../widgets/game_card.dart';

class FavoritesPage extends StatelessWidget {
  const FavoritesPage({super.key, required this.onOpenGame});
  final ValueChanged<Game> onOpenGame;

  @override
  Widget build(BuildContext context) {
    return SafeArea(bottom: false, child: Column(children: [
      Container(width: double.infinity, color: gameNavy, padding: const EdgeInsets.fromLTRB(18, 18, 18, 20), child: const Text('Game favorit', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 21))),
      Expanded(child: ValueListenableBuilder<Set<String>>(valueListenable: favoriteGameIds, builder: (context, favoriteIds, _) {
        final favoriteGames = games.where((game) => favoriteIds.contains(game.id)).toList();
        if (favoriteGames.isEmpty) return const Center(child: Padding(padding: EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.favorite_border, size: 50, color: gameTeal), SizedBox(height: 12), Text('Belum ada game favorit', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)), SizedBox(height: 6), Text('Tekan ikon hati pada kartu game untuk menyimpannya.', textAlign: TextAlign.center, style: TextStyle(fontSize: 12))])));
        return ListView.builder(padding: const EdgeInsets.all(16), itemCount: favoriteGames.length, itemBuilder: (context, index) => GameListCard(game: favoriteGames[index], onTap: () => onOpenGame(favoriteGames[index])));
      })),
    ]));
  }
}
