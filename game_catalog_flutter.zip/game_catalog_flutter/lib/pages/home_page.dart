import 'package:flutter/material.dart';

import '../data/game_data.dart';
import '../main.dart';
import '../models/game.dart';
import '../widgets/game_card.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key, required this.onSearch, required this.onSelectCategory, required this.onOpenGame});
  final ValueChanged<String> onSearch;
  final ValueChanged<String> onSelectCategory;
  final ValueChanged<Game> onOpenGame;

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController _searchController = TextEditingController();

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: false,
      child: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: Container(
              padding: const EdgeInsets.fromLTRB(18, 18, 18, 23),
              decoration: const BoxDecoration(color: gameNavy, borderRadius: BorderRadius.vertical(bottom: Radius.circular(24))),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('Selamat Datang', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 20)),
                    const SizedBox(height: 4),
                    Text('Info game apa yang kamu butuhkan?', style: TextStyle(color: Colors.white.withOpacity(0.72), fontSize: 12)),
                  ])),
                  Container(width: 39, height: 39, decoration: const BoxDecoration(color: Color(0xFF52B89A), shape: BoxShape.circle), child: const Icon(Icons.sports_esports_rounded, color: Colors.white, size: 23)),
                ]),
                const SizedBox(height: 18),
                Container(
                  decoration: BoxDecoration(color: gameTeal, borderRadius: BorderRadius.circular(14)),
                  padding: const EdgeInsets.only(left: 12, right: 5),
                  child: Row(children: [
                    const Icon(Icons.search, color: gameOrange, size: 21),
                    const SizedBox(width: 7),
                    Expanded(child: TextField(controller: _searchController, style: const TextStyle(color: Colors.white, fontSize: 12), textInputAction: TextInputAction.search, onSubmitted: widget.onSearch, decoration: const InputDecoration(hintText: 'Masukkan judul game', hintStyle: TextStyle(color: Color(0xFFC3D1D1), fontSize: 11), border: InputBorder.none, isDense: true, contentPadding: EdgeInsets.symmetric(vertical: 13)))),
                    IconButton(onPressed: () => widget.onSearch(_searchController.text.trim()), icon: const Icon(Icons.search_rounded, color: Colors.white), tooltip: 'Cari game'),
                  ]),
                ),
              ]),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 17, 16, 4),
              child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                _CategoryItem(icon: Icons.my_location, label: 'Menembak', color: const Color(0xFFB98A00), onTap: () => widget.onSelectCategory('Menembak')),
                _CategoryItem(icon: Icons.directions_car_filled, label: 'Balap', color: const Color(0xFFBA7966), onTap: () => widget.onSelectCategory('Balap')),
                _CategoryItem(icon: Icons.castle, label: 'Strategi', color: const Color(0xFF7A6455), onTap: () => widget.onSelectCategory('Strategi')),
                _CategoryItem(icon: Icons.auto_awesome, label: 'RPG', color: const Color(0xFF77957F), onTap: () => widget.onSelectCategory('RPG')),
              ]),
            ),
          ),
          SliverToBoxAdapter(child: _SectionTitle(title: 'Game Populer', actionLabel: 'Lihat semua', onTap: () => widget.onSearch(''))),
          SliverToBoxAdapter(
            child: SizedBox(height: 138, child: ListView.builder(padding: const EdgeInsets.symmetric(horizontal: 16), scrollDirection: Axis.horizontal, itemCount: games.length > 5 ? 5 : games.length, itemBuilder: (context, index) => GameArtworkCard(game: games[index], onTap: () => widget.onOpenGame(games[index])))),
          ),
          SliverToBoxAdapter(child: _SectionTitle(title: 'Game Terbaru', actionLabel: 'Jelajahi', onTap: () => widget.onSearch(''))),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 22),
            sliver: SliverList.builder(itemCount: games.length > 4 ? 4 : games.length, itemBuilder: (context, index) => GameListCard(game: games[index], onTap: () => widget.onOpenGame(games[index]))),
          ),
        ],
      ),
    );
  }
}

class _CategoryItem extends StatelessWidget {
  const _CategoryItem({required this.icon, required this.label, required this.color, required this.onTap});
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(onTap: onTap, borderRadius: BorderRadius.circular(12), child: SizedBox(width: 70, child: Column(children: [Container(width: 48, height: 48, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(13)), child: Icon(icon, color: Colors.white, size: 26)), const SizedBox(height: 6), Text(label, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 10))])));
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({required this.title, required this.actionLabel, required this.onTap});
  final String title;
  final String actionLabel;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(padding: const EdgeInsets.fromLTRB(18, 16, 16, 10), child: Row(children: [Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16, color: gameInk))), TextButton(onPressed: onTap, style: TextButton.styleFrom(foregroundColor: gameTeal, visualDensity: VisualDensity.compact), child: Text(actionLabel, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700)))]));
  }
}
