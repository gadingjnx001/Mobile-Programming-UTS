import '../models/game.dart';

/// Data contoh (dummy), bukan hasil pemanggilan API langsung.
/// Nilai spesifikasi ditujukan sebagai contoh tampilan tugas dan perlu diverifikasi
/// sebelum digunakan sebagai informasi teknis resmi suatu game.
const List<Game> games = [
  Game(
    id: 'game-01', title: 'Overwatch 2', genre: 'Shooter', category: 'Menembak',
    platform: 'PC', releaseDate: '04 Oktober 2022',
    description: 'Game aksi tim dengan pertandingan cepat dan pilihan hero dengan kemampuan berbeda. Pilih peran, susun strategi, dan bekerja sama untuk meraih tujuan tim.',
    minOs: 'Windows 10 64-bit', minProcessor: 'Intel Core i3 / setara',
    minMemory: '6 GB RAM', minGraphics: 'GPU kompatibel DirectX 11', storage: '50 GB',
    imageAsset: 'assets/images/hero_shooter.jpg', rating: 4.6,
  ),
  Game(
    id: 'game-02', title: 'Diablo Immortal', genre: 'MMORPG', category: 'RPG',
    platform: 'PC / Mobile', releaseDate: '02 Juni 2022',
    description: 'Petualangan aksi fantasi gelap dengan eksplorasi dungeon, perlengkapan, dan pengembangan karakter. Data dalam aplikasi ini digunakan sebagai contoh katalog.',
    minOs: 'Windows 10 64-bit', minProcessor: 'Intel Core i3 / setara',
    minMemory: '4 GB RAM', minGraphics: 'GPU dengan dukungan DirectX', storage: '25 GB',
    imageAsset: 'assets/images/dark_fantasy.jpg', rating: 4.4,
  ),
  Game(
    id: 'game-03', title: 'Lost Ark', genre: 'ARPG', category: 'RPG',
    platform: 'PC', releaseDate: '11 Februari 2022',
    description: 'Action RPG dengan dunia fantasi luas, pertarungan real-time, serta aktivitas eksplorasi dan pengembangan karakter.',
    minOs: 'Windows 10 64-bit', minProcessor: 'Intel Core i3 / setara',
    minMemory: '8 GB RAM', minGraphics: 'GPU kelas menengah', storage: '50 GB',
    imageAsset: 'assets/images/fantasy_world.jpg', rating: 4.3,
  ),
  Game(
    id: 'game-04', title: 'PUBG: Battlegrounds', genre: 'Shooter', category: 'Menembak',
    platform: 'PC / Console', releaseDate: '12 Januari 2022',
    description: 'Permainan survival kompetitif yang menuntut strategi, pengamatan, pengelolaan perlengkapan, dan kerja sama ketika bermain dalam tim.',
    minOs: 'Windows 10 64-bit', minProcessor: 'Intel Core i5 / setara',
    minMemory: '8 GB RAM', minGraphics: 'GPU dengan VRAM 2 GB', storage: '40 GB',
    imageAsset: 'assets/images/military_ops.jpg', rating: 4.2,
  ),
  Game(
    id: 'game-05', title: 'Enlisted', genre: 'Shooter', category: 'Menembak',
    platform: 'PC / Console', releaseDate: '08 April 2021',
    description: 'Game aksi bertema operasi militer dengan unit dan lingkungan pertempuran yang luas. Informasi di halaman ini merupakan data dummy untuk demonstrasi UI.',
    minOs: 'Windows 10 64-bit', minProcessor: 'Intel Core i3 / setara',
    minMemory: '8 GB RAM', minGraphics: 'GPU dengan dukungan DirectX', storage: '30 GB',
    imageAsset: 'assets/images/mech_sci_fi.jpg', rating: 4.1,
  ),
  Game(
    id: 'game-06', title: 'Forge of Empires', genre: 'Strategy', category: 'Strategi',
    platform: 'Browser / Mobile', releaseDate: '17 April 2012',
    description: 'Game strategi pembangunan yang mengajak pemain mengembangkan permukiman, mengelola sumber daya, dan memajukan peradaban dari waktu ke waktu.',
    minOs: 'Browser modern / Android / iOS', minProcessor: 'Perangkat kompatibel',
    minMemory: '2 GB RAM disarankan', minGraphics: 'Grafis perangkat standar', storage: 'Bergantung platform',
    imageAsset: 'assets/images/strategy_kingdom.jpg', rating: 4.0,
  ),
  Game(
    id: 'game-07', title: 'Skybound Legends', genre: 'Adventure RPG', category: 'RPG',
    platform: 'PC / Mobile', releaseDate: '15 Mei 2024',
    description: 'Petualangan fantasi dalam dunia pulau terapung. Judul ini adalah data rekaan untuk memperlihatkan bahwa katalog dapat menerima entri baru.',
    minOs: 'Windows 10 / Android 10+', minProcessor: 'Quad-core modern',
    minMemory: '4 GB RAM', minGraphics: 'GPU kompatibel Vulkan / DirectX', storage: '20 GB',
    imageAsset: 'assets/images/fantasy_world.jpg', rating: 4.5,
  ),
  Game(
    id: 'game-08', title: 'Turbo Circuit', genre: 'Racing', category: 'Balap',
    platform: 'PC / Console', releaseDate: '20 Agustus 2024',
    description: 'Game balap futuristis dengan lintasan pesisir, mobil berkecepatan tinggi, dan tantangan time trial. Judul dan data merupakan contoh rekaan untuk kebutuhan tugas.',
    minOs: 'Windows 10 64-bit', minProcessor: 'Quad-core modern',
    minMemory: '8 GB RAM', minGraphics: 'GPU dengan VRAM 4 GB', storage: '35 GB',
    imageAsset: 'assets/images/racing.jpg', rating: 4.4,
  ),
];

const List<String> gameCategories = ['Semua', 'Menembak', 'Balap', 'Strategi', 'RPG'];
