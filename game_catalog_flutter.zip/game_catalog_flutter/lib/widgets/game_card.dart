import 'package:flutter/material.dart';

import '../main.dart';
import '../models/game.dart';
import '../state/favorites_store.dart';

class GameListCard extends StatelessWidget {
  const GameListCard({super.key, required this.game, required this.onTap});

  final Game game;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      color: Colors.white,
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(9),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(11),
              child: Image.asset(game.imageAsset, width: 62, height: 66, fit: BoxFit.cover),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(game.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
                  const SizedBox(height: 4),
                  Text(game.genre, style: TextStyle(fontSize: 11, color: Colors.blueGrey.shade600)),
                  const SizedBox(height: 3),
                  Text(game.releaseDate, style: TextStyle(fontSize: 10, color: Colors.blueGrey.shade700)),
                ],
              ),
            ),
            const SizedBox(width: 5),
            Column(
              children: [
                SizedBox(
                  height: 29,
                  child: ElevatedButton(
                    onPressed: onTap,
                    style: ElevatedButton.styleFrom(backgroundColor: gameOrange, foregroundColor: gameNavy, elevation: 0, padding: const EdgeInsets.symmetric(horizontal: 10), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
                    child: const Text('Baca Info', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800)),
                  ),
                ),
                const SizedBox(height: 3),
                ValueListenableBuilder<Set<String>>(
                  valueListenable: favoriteGameIds,
                  builder: (context, favorites, _) {
                    final isFavorite = favorites.contains(game.id);
                    return InkWell(
                      onTap: () => toggleFavorite(game.id),
                      borderRadius: BorderRadius.circular(30),
                      child: Padding(
                        padding: const EdgeInsets.all(4),
                        child: Icon(isFavorite ? Icons.favorite : Icons.favorite_border, color: isFavorite ? Colors.redAccent : Colors.blueGrey, size: 17),
                      ),
                    );
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class GameArtworkCard extends StatelessWidget {
  const GameArtworkCard({super.key, required this.game, required this.onTap});

  final Game game;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        width: 205,
        margin: const EdgeInsets.only(right: 10),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), boxShadow: const [BoxShadow(color: Color(0x18000000), blurRadius: 5, offset: Offset(0, 2))]),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(14),
          child: Stack(
            fit: StackFit.expand,
            children: [
              Image.asset(game.imageAsset, fit: BoxFit.cover),
              Align(
                alignment: Alignment.bottomCenter,
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Color(0xD9000000)])),
                  child: Column(mainAxisAlignment: MainAxisAlignment.end, crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(game.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 13)),
                    Text('${game.genre}  •  ★ ${game.rating.toStringAsFixed(1)}', style: const TextStyle(color: Colors.white, fontSize: 10)),
                  ]),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
