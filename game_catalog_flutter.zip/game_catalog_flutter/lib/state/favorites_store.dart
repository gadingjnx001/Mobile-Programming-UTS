import 'package:flutter/foundation.dart';

/// Penyimpanan favorit dalam memori untuk kebutuhan demonstrasi UTS.
/// Data akan kembali kosong ketika aplikasi ditutup; belum memakai database.
final ValueNotifier<Set<String>> favoriteGameIds = ValueNotifier<Set<String>>(<String>{});

void toggleFavorite(String gameId) {
  final next = Set<String>.from(favoriteGameIds.value);
  if (!next.add(gameId)) next.remove(gameId);
  favoriteGameIds.value = next;
}
