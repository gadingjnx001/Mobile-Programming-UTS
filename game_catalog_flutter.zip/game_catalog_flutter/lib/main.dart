import 'package:flutter/material.dart';

import 'models/game.dart';
import 'pages/explore_page.dart';
import 'pages/favorites_page.dart';
import 'pages/game_detail_page.dart';
import 'pages/home_page.dart';

const Color gameNavy = Color(0xFF12383D);
const Color gameTeal = Color(0xFF24545A);
const Color gameCream = Color(0xFFFFF1BE);
const Color gameOrange = Color(0xFFFFA800);
const Color gameInk = Color(0xFF202A2D);

void main() => runApp(const GameCatalogApp());

class GameCatalogApp extends StatelessWidget {
  const GameCatalogApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'GameVerse - Katalog Game',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: gameCream,
        colorScheme: ColorScheme.fromSeed(seedColor: gameTeal, primary: gameTeal, secondary: gameOrange),
        fontFamily: 'Roboto',
        appBarTheme: const AppBarTheme(backgroundColor: gameNavy, foregroundColor: Colors.white, elevation: 0),
        textTheme: const TextTheme(
          titleLarge: TextStyle(fontWeight: FontWeight.w800, color: gameInk),
          titleMedium: TextStyle(fontWeight: FontWeight.w700, color: gameInk),
          bodyMedium: TextStyle(color: gameInk),
        ),
      ),
      home: const MainNavigation(),
    );
  }
}

class MainNavigation extends StatefulWidget {
  const MainNavigation({super.key});

  @override
  State<MainNavigation> createState() => _MainNavigationState();
}

class _MainNavigationState extends State<MainNavigation> {
  int _selectedIndex = 0;
  String _query = '';
  String _category = 'Semua';

  void _goExplore({String query = '', String category = 'Semua'}) {
    setState(() {
      _selectedIndex = 1;
      _query = query;
      _category = category;
    });
  }

  void _openGame(Game game) {
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => GameDetailPage(game: game)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _selectedIndex,
        children: [
          HomePage(onSearch: (query) => _goExplore(query: query), onSelectCategory: (category) => _goExplore(category: category), onOpenGame: _openGame),
          ExplorePage(key: ValueKey('$_query-$_category'), initialQuery: _query, initialCategory: _category, onOpenGame: _openGame),
          FavoritesPage(onOpenGame: _openGame),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        backgroundColor: Colors.white,
        indicatorColor: const Color(0xFFFFE2A0),
        selectedIndex: _selectedIndex,
        onDestinationSelected: (index) => setState(() => _selectedIndex = index),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'Beranda'),
          NavigationDestination(icon: Icon(Icons.sports_esports_outlined), selectedIcon: Icon(Icons.sports_esports), label: 'Daftar Game'),
          NavigationDestination(icon: Icon(Icons.favorite_border), selectedIcon: Icon(Icons.favorite), label: 'Favorit'),
        ],
      ),
    );
  }
}
