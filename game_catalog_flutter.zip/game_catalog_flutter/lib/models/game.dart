/// Model data game. Struktur ini dapat dipetakan ke respons JSON dari API.
class Game {
  const Game({
    required this.id,
    required this.title,
    required this.genre,
    required this.category,
    required this.platform,
    required this.releaseDate,
    required this.description,
    required this.minOs,
    required this.minProcessor,
    required this.minMemory,
    required this.minGraphics,
    required this.storage,
    required this.imageAsset,
    required this.rating,
  });

  final String id;
  final String title;
  final String genre;
  final String category;
  final String platform;
  final String releaseDate;
  final String description;
  final String minOs;
  final String minProcessor;
  final String minMemory;
  final String minGraphics;
  final String storage;
  final String imageAsset;
  final double rating;
}
